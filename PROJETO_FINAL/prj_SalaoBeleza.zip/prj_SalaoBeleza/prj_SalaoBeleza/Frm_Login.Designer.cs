﻿namespace prj_SalaoBeleza
{
    partial class Frm_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Login));
            this.txtb_Nome = new System.Windows.Forms.TextBox();
            this.txtb_Senha = new System.Windows.Forms.TextBox();
            this.btn_Acessar = new System.Windows.Forms.Button();
            this.btn_CadUse = new System.Windows.Forms.Button();
            this.btn_Fechar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtb_Nome
            // 
            this.txtb_Nome.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtb_Nome.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtb_Nome.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtb_Nome.Location = new System.Drawing.Point(80, 140);
            this.txtb_Nome.Name = "txtb_Nome";
            this.txtb_Nome.Size = new System.Drawing.Size(246, 32);
            this.txtb_Nome.TabIndex = 0;
            // 
            // txtb_Senha
            // 
            this.txtb_Senha.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtb_Senha.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtb_Senha.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtb_Senha.Location = new System.Drawing.Point(80, 214);
            this.txtb_Senha.Name = "txtb_Senha";
            this.txtb_Senha.Size = new System.Drawing.Size(246, 32);
            this.txtb_Senha.TabIndex = 1;
            this.txtb_Senha.UseSystemPasswordChar = true;
            // 
            // btn_Acessar
            // 
            this.btn_Acessar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Acessar.BackgroundImage")));
            this.btn_Acessar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Acessar.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_Acessar.FlatAppearance.BorderSize = 0;
            this.btn_Acessar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btn_Acessar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btn_Acessar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Acessar.Location = new System.Drawing.Point(1, 292);
            this.btn_Acessar.Name = "btn_Acessar";
            this.btn_Acessar.Size = new System.Drawing.Size(165, 51);
            this.btn_Acessar.TabIndex = 2;
            this.btn_Acessar.UseVisualStyleBackColor = true;
            this.btn_Acessar.Click += new System.EventHandler(this.btn_Acessar_Click);
            // 
            // btn_CadUse
            // 
            this.btn_CadUse.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_CadUse.BackgroundImage")));
            this.btn_CadUse.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_CadUse.FlatAppearance.BorderSize = 0;
            this.btn_CadUse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CadUse.Location = new System.Drawing.Point(171, 292);
            this.btn_CadUse.Name = "btn_CadUse";
            this.btn_CadUse.Size = new System.Drawing.Size(155, 51);
            this.btn_CadUse.TabIndex = 3;
            this.btn_CadUse.UseVisualStyleBackColor = true;
            this.btn_CadUse.Click += new System.EventHandler(this.btn_CadUse_Click);
            // 
            // btn_Fechar
            // 
            this.btn_Fechar.BackColor = System.Drawing.Color.Red;
            this.btn_Fechar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Fechar.BackgroundImage")));
            this.btn_Fechar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Fechar.FlatAppearance.BorderSize = 0;
            this.btn_Fechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Fechar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Fechar.Location = new System.Drawing.Point(907, 1);
            this.btn_Fechar.Name = "btn_Fechar";
            this.btn_Fechar.Size = new System.Drawing.Size(41, 36);
            this.btn_Fechar.TabIndex = 4;
            this.btn_Fechar.UseVisualStyleBackColor = false;
            this.btn_Fechar.Click += new System.EventHandler(this.btn_Fechar_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(80, 349);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(153, 51);
            this.button1.TabIndex = 6;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button2.Location = new System.Drawing.Point(756, -1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(39, 32);
            this.button2.TabIndex = 7;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Frm_Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(791, 429);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_Fechar);
            this.Controls.Add(this.btn_CadUse);
            this.Controls.Add(this.btn_Acessar);
            this.Controls.Add(this.txtb_Senha);
            this.Controls.Add(this.txtb_Nome);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Frm_Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Frm_Login";
            this.Load += new System.EventHandler(this.Frm_Login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtb_Nome;
        private TextBox txtb_Senha;
        private Button btn_Acessar;
        private Button btn_CadUse;
        private Button btn_Fechar;
        private Button button1;
        private Button button2;
    }
}