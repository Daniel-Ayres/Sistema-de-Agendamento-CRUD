﻿namespace prj_SalaoBeleza.View
{
    partial class Frm_CadClie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_CadClie));
            this.txtb_Nome = new System.Windows.Forms.TextBox();
            this.txtb_Email = new System.Windows.Forms.TextBox();
            this.txtb_Tel = new System.Windows.Forms.TextBox();
            this.txtb_Ender = new System.Windows.Forms.TextBox();
            this.txtb_Cid = new System.Windows.Forms.TextBox();
            this.txtb_Esta = new System.Windows.Forms.TextBox();
            this.txtb_Pais = new System.Windows.Forms.TextBox();
            this.btn_CadClien = new System.Windows.Forms.Button();
            this.lbl_Tel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtb_Nome
            // 
            this.txtb_Nome.BackColor = System.Drawing.SystemColors.ControlDark;
            this.txtb_Nome.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtb_Nome.Location = new System.Drawing.Point(25, 122);
            this.txtb_Nome.Name = "txtb_Nome";
            this.txtb_Nome.Size = new System.Drawing.Size(188, 38);
            this.txtb_Nome.TabIndex = 0;
            // 
            // txtb_Email
            // 
            this.txtb_Email.BackColor = System.Drawing.SystemColors.ControlDark;
            this.txtb_Email.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtb_Email.Location = new System.Drawing.Point(25, 179);
            this.txtb_Email.Name = "txtb_Email";
            this.txtb_Email.Size = new System.Drawing.Size(200, 38);
            this.txtb_Email.TabIndex = 1;
            // 
            // txtb_Tel
            // 
            this.txtb_Tel.BackColor = System.Drawing.SystemColors.ControlDark;
            this.txtb_Tel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtb_Tel.Location = new System.Drawing.Point(496, 244);
            this.txtb_Tel.Name = "txtb_Tel";
            this.txtb_Tel.Size = new System.Drawing.Size(161, 29);
            this.txtb_Tel.TabIndex = 2;
            // 
            // txtb_Ender
            // 
            this.txtb_Ender.BackColor = System.Drawing.SystemColors.ControlDark;
            this.txtb_Ender.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtb_Ender.Location = new System.Drawing.Point(25, 244);
            this.txtb_Ender.Name = "txtb_Ender";
            this.txtb_Ender.Size = new System.Drawing.Size(200, 38);
            this.txtb_Ender.TabIndex = 3;
            // 
            // txtb_Cid
            // 
            this.txtb_Cid.BackColor = System.Drawing.SystemColors.ControlDark;
            this.txtb_Cid.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtb_Cid.Location = new System.Drawing.Point(261, 119);
            this.txtb_Cid.Name = "txtb_Cid";
            this.txtb_Cid.Size = new System.Drawing.Size(205, 38);
            this.txtb_Cid.TabIndex = 4;
            // 
            // txtb_Esta
            // 
            this.txtb_Esta.BackColor = System.Drawing.SystemColors.ControlDark;
            this.txtb_Esta.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtb_Esta.Location = new System.Drawing.Point(270, 183);
            this.txtb_Esta.Name = "txtb_Esta";
            this.txtb_Esta.Size = new System.Drawing.Size(196, 34);
            this.txtb_Esta.TabIndex = 5;
            // 
            // txtb_Pais
            // 
            this.txtb_Pais.BackColor = System.Drawing.SystemColors.ControlDark;
            this.txtb_Pais.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtb_Pais.ForeColor = System.Drawing.SystemColors.Window;
            this.txtb_Pais.Location = new System.Drawing.Point(270, 244);
            this.txtb_Pais.Name = "txtb_Pais";
            this.txtb_Pais.Size = new System.Drawing.Size(196, 29);
            this.txtb_Pais.TabIndex = 6;
            // 
            // btn_CadClien
            // 
            this.btn_CadClien.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_CadClien.BackgroundImage")));
            this.btn_CadClien.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_CadClien.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_CadClien.Location = new System.Drawing.Point(545, 369);
            this.btn_CadClien.Name = "btn_CadClien";
            this.btn_CadClien.Size = new System.Drawing.Size(180, 60);
            this.btn_CadClien.TabIndex = 7;
            this.btn_CadClien.UseVisualStyleBackColor = true;
            this.btn_CadClien.Click += new System.EventHandler(this.btn_Cad_Click);
            // 
            // lbl_Tel
            // 
            this.lbl_Tel.AutoSize = true;
            this.lbl_Tel.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Tel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_Tel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Tel.Location = new System.Drawing.Point(529, 220);
            this.lbl_Tel.Name = "lbl_Tel";
            this.lbl_Tel.Size = new System.Drawing.Size(91, 21);
            this.lbl_Tel.TabIndex = 8;
            this.lbl_Tel.Text = "TELEFONE ";
            // 
            // Frm_CadClie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl_Tel);
            this.Controls.Add(this.btn_CadClien);
            this.Controls.Add(this.txtb_Pais);
            this.Controls.Add(this.txtb_Esta);
            this.Controls.Add(this.txtb_Cid);
            this.Controls.Add(this.txtb_Ender);
            this.Controls.Add(this.txtb_Tel);
            this.Controls.Add(this.txtb_Email);
            this.Controls.Add(this.txtb_Nome);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Frm_CadClie";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CADASTRO CLIENTE";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtb_Nome;
        private TextBox txtb_Email;
        private TextBox txtb_Tel;
        private TextBox txtb_Ender;
        private TextBox txtb_Cid;
        private TextBox txtb_Esta;
        private TextBox txtb_Pais;
        private Button btn_CadClien;
        private Label lbl_Tel;
    }
}