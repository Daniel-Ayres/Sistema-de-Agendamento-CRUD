﻿namespace prj_SalaoBeleza
{
    partial class btn_Agend
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(btn_Agend));
            this.btn_CadClie = new System.Windows.Forms.Button();
            this.btn_ExClie = new System.Windows.Forms.Button();
            this.btn_Agen = new System.Windows.Forms.Button();
            this.btn_AgendEx = new System.Windows.Forms.Button();
            this.btn_Servi = new System.Windows.Forms.Button();
            this.btn_ServiEx = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_CadClie
            // 
            this.btn_CadClie.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_CadClie.BackgroundImage")));
            this.btn_CadClie.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_CadClie.FlatAppearance.BorderSize = 0;
            this.btn_CadClie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CadClie.Location = new System.Drawing.Point(12, 256);
            this.btn_CadClie.Name = "btn_CadClie";
            this.btn_CadClie.Size = new System.Drawing.Size(237, 72);
            this.btn_CadClie.TabIndex = 5;
            this.btn_CadClie.UseVisualStyleBackColor = true;
            this.btn_CadClie.Click += new System.EventHandler(this.btn_CadClie_Click);
            // 
            // btn_ExClie
            // 
            this.btn_ExClie.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_ExClie.BackgroundImage")));
            this.btn_ExClie.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_ExClie.FlatAppearance.BorderSize = 0;
            this.btn_ExClie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ExClie.Location = new System.Drawing.Point(12, 334);
            this.btn_ExClie.Name = "btn_ExClie";
            this.btn_ExClie.Size = new System.Drawing.Size(237, 65);
            this.btn_ExClie.TabIndex = 7;
            this.btn_ExClie.UseVisualStyleBackColor = true;
            this.btn_ExClie.Click += new System.EventHandler(this.btn_ExClie_Click_1);
            // 
            // btn_Agen
            // 
            this.btn_Agen.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Agen.BackgroundImage")));
            this.btn_Agen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_Agen.FlatAppearance.BorderSize = 0;
            this.btn_Agen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Agen.Location = new System.Drawing.Point(12, 101);
            this.btn_Agen.Name = "btn_Agen";
            this.btn_Agen.Size = new System.Drawing.Size(237, 74);
            this.btn_Agen.TabIndex = 8;
            this.btn_Agen.UseVisualStyleBackColor = true;
            this.btn_Agen.Click += new System.EventHandler(this.btn_Agen_Click);
            // 
            // btn_AgendEx
            // 
            this.btn_AgendEx.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_AgendEx.BackgroundImage")));
            this.btn_AgendEx.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_AgendEx.FlatAppearance.BorderSize = 0;
            this.btn_AgendEx.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AgendEx.Location = new System.Drawing.Point(12, 181);
            this.btn_AgendEx.Name = "btn_AgendEx";
            this.btn_AgendEx.Size = new System.Drawing.Size(237, 69);
            this.btn_AgendEx.TabIndex = 9;
            this.btn_AgendEx.UseVisualStyleBackColor = true;
            this.btn_AgendEx.Click += new System.EventHandler(this.btn_AgendEx_Click);
            // 
            // btn_Servi
            // 
            this.btn_Servi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Servi.BackgroundImage")));
            this.btn_Servi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_Servi.FlatAppearance.BorderSize = 0;
            this.btn_Servi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Servi.Location = new System.Drawing.Point(12, 405);
            this.btn_Servi.Name = "btn_Servi";
            this.btn_Servi.Size = new System.Drawing.Size(227, 73);
            this.btn_Servi.TabIndex = 10;
            this.btn_Servi.UseVisualStyleBackColor = true;
            this.btn_Servi.Click += new System.EventHandler(this.btn_Servi_Click);
            // 
            // btn_ServiEx
            // 
            this.btn_ServiEx.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_ServiEx.BackgroundImage")));
            this.btn_ServiEx.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_ServiEx.FlatAppearance.BorderSize = 0;
            this.btn_ServiEx.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ServiEx.Location = new System.Drawing.Point(12, 484);
            this.btn_ServiEx.Name = "btn_ServiEx";
            this.btn_ServiEx.Size = new System.Drawing.Size(237, 73);
            this.btn_ServiEx.TabIndex = 11;
            this.btn_ServiEx.UseVisualStyleBackColor = true;
            this.btn_ServiEx.Click += new System.EventHandler(this.btn_ServiEx_Click);
            // 
            // btn_Agend
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(961, 598);
            this.Controls.Add(this.btn_ServiEx);
            this.Controls.Add(this.btn_Servi);
            this.Controls.Add(this.btn_AgendEx);
            this.Controls.Add(this.btn_Agen);
            this.Controls.Add(this.btn_ExClie);
            this.Controls.Add(this.btn_CadClie);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "btn_Agend";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ACESSO AO SISTEMA";
            this.Load += new System.EventHandler(this.Frm_Principal_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Button btn_CadClie;
        private Button btn_ExClie;
        private Button btn_Agen;
        private Button btn_AgendEx;
        private Button btn_Servi;
        private Button btn_ServiEx;
    }
}